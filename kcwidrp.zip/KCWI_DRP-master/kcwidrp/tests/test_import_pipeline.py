import pytest

def test_import_pipeline():
    import kcwidrp.pipelines.kcwi_pipeline

